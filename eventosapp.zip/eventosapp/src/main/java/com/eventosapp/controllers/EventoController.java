package com.eventosapp.controllers;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.eventosapp.model.Convidado;
import com.eventosapp.model.Evento;
import com.eventosapp.repository.ConvidadoRepository;
import com.eventosapp.repository.EventoRepository;

@Controller
public class EventoController {

	@Autowired
	EventoRepository er;
	ConvidadoRepository cr;
	
	@RequestMapping(value="/cadastrarEvento", method= RequestMethod.GET)
	public String form() {
		
		return "evento/evento-form";
	}
	
	@RequestMapping(value="/cadastrarEvento", method= RequestMethod.POST)
	public String cadastra(Evento evento) {
		
		er.save(evento);
		return "redirect:/cadastrarEvento";
	}
	
	@RequestMapping(value="/listarEventos")
	public ModelAndView listar() {
		ModelAndView mv = new ModelAndView("index");
		Iterable<Evento> eventos = er.findAll();
		
		mv.addObject("eventos", eventos);
		return mv;
	}
	
	@RequestMapping(value="/evento/{id}", method= RequestMethod.GET)
	public ModelAndView detalhe(@PathVariable("id") long id) {
		ModelAndView mv = new ModelAndView("evento/detail");
		Evento evento = er.findOne(id);
		mv.addObject("evento", evento);
		return mv;
	}
	
	@RequestMapping(value="/evento/{id}", method=RequestMethod.POST)
	public String detalhePost(@PathVariable("id") long id, Convidado convidado) {
		Evento evento = er.findOne(id);
		convidado.setEvento(evento);
		cr.save(convidado);
		
		return "redirect:/evento/{id}";
	}
	
	@RequestMapping(value="/atualizar/{id}")
	public ModelAndView update(@PathVariable("id") long id, Evento evento) {
		ModelAndView mv = new ModelAndView("evento-form");
		evento.setId(id);
		mv.addObject("form", evento);
		return mv;
	}
	
	
}
