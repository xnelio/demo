package com.eventosapp.model;



import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Convidado implements Serializable {
	
	
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 351709459945399571L;
	@Id
	private String rg;
	private String nomeDoConvidado;
	
	
	@ManyToOne
	private Evento evento;
	
	public Evento getEvento() {
		return evento;
	}
	public void setEvento(Evento evento) {
		this.evento = evento;
	}
	
	public String getNomeDoConvidado() {
		return nomeDoConvidado;
	}
	public void setNomeDoConvidado(String nomeDoConvidado) {
		this.nomeDoConvidado = nomeDoConvidado;
	}
	public String getRg() {
		return rg;
	}
	public void setRg(String rg) {
		this.rg = rg;
	}
	
	
	

}
