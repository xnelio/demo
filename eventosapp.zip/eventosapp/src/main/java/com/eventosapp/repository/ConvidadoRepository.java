package com.eventosapp.repository;

import org.springframework.data.repository.CrudRepository;

import com.eventosapp.model.Convidado;

public interface ConvidadoRepository extends CrudRepository<Convidado, Long> {

	
}
